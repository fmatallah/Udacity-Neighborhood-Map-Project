// locations array used to place markers on the map as well as filter them
var locations = [{
        name: "Red Sea Mall",
        category: "Shopping",
        lat: 21.627586,lng: 39.110829,  
        location: {lat: 21.627586,lng: 39.110829}      
    },
    {
        name: "Faqeh Aquarium",
        category: "Entertainment",
        lat: 21.572566,lng: 39.109483,
        location: {lat: 21.572566,lng: 39.109483}      
    },
    {
        name: "King Fahad Fountain",
        category: "Tourism",
        lat: 21.515764, lng: 39.144974,
        location: {lat: 21.515764, lng: 39.144974}
    },
    {
        name: "Tahliya Center",
        category: "Shopping",
        lat: 21.549879, lng: 39.148072,
        location: {lat: 21.5197148, lng: 39.15196190000006}       
    },
    {
        name: "Bait Nassif",
        category: "Tourism",
        lat: 21.48412, lng:39.18761,
        location: {lat: 21.48412, lng:39.18761}      
    },
];
//Declar variables globally 
var map;
var locInfoWindow;
var markers = [];
var bounds;
var marker;

//---------------------------------------------------------
//Initialization function to load map 
//---------------------------------------------------------
function initMap() {     
   var mapOptions = {
        center:{lat: 21.285407, lng: 39.237551},
        zoom: 10
    }
    //Display a map on the page
    map = new google.maps.Map(document.getElementById('map'), mapOptions);

    locInfoWindow = new google.maps.InfoWindow();

    bounds = new google.maps.LatLngBounds();
    
    ko.applyBindings(new viewModel());
     
}// END of initMap function--------------------------------
     
//---------------------------------------------------------
//Add marker Function
//---------------------------------------------------------
    var addMarker = function(location) {
        var self = this;

        this.name = location.name;
        this.position = location.location;

        var position = new google.maps.LatLng(location.lat, location.lng);
  
        this.marker = new google.maps.Marker({
            position: this.position,
            title: this.name,
            category: location.category,
            animation: google.maps.Animation.DROP 
            }); 
        
        //FOURSQARE Code
        this.address = "";
        this.street = "";
        this.visible = ko.observable(true);
        var clientID = "UAYA3LVXOG4RE5DP2E5KGYHL0AGQLKJEVUESGCU3R3AEN0Q5" ;
        var clientSecret = "YDYZUDTJGU3ZAM531H2MQNKCNJUHBRVGQ01HJR2CBBEPESLZ";
        //Get JSON request of foursquare data
        var reqURL = 'https://api.foursquare.com/v2/venues/search?ll=' + location.lat + ',' + location.lng + '&client_id=' + clientID + '&client_secret=' + clientSecret + '&v=20160118'+ '&query=' + this.name;
        $.getJSON(reqURL).done(function(data) {
        var results = data.response.venues[0];
        self.address =  results.location.formattedAddress;    

    }).fail(function() {
        alert('Something went wrong with foursquare');
    });//---------------------------------------------------------
        self.filterMarkers = ko.computed(function() {
            if(self.visible() === true) {
                self.marker.setMap(map);
                bounds.extend(self.marker.position);
                map.fitBounds(bounds);
            }
            else {
            self.marker.setMap(null);
            }

        });     
        // Create an onclick event to open an infowindow at each marker.
        this.marker.addListener('click', function() {
            createInfoWindow(this, locInfoWindow, self.address, self.street);
        });

        // show item info when selected from list
        this.show = function(location) {
            google.maps.event.trigger(self.marker, 'click');
        };

    }//END of addMarker function---------------------------

//---------------------------------------------------------
//Create location's info windows 
//---------------------------------------------------------
function createInfoWindow(marker, infowindow, address, street) {   
    if (infowindow.marker != marker) {
        markerBounce(marker);
        infowindow.marker = marker;
        infowindow.setContent('<div>' + '<h3>'+ marker.title + '<h3>'+ '<br>'+address+'<br>'+street+'<h4>'+ marker.category+'</h4>'+'</div>');
        infowindow.open(map, marker);
        //Make sure the marker property is cleared if the infowindow is closed
        infowindow.addListener('closeclick',function(){
        infowindow.setMarker = null;
        });
    }  
}//END of createInfoWindow function------------------------

//---------------------------------------------------------
//Animate markers
//---------------------------------------------------------
function markerBounce(marker) {
    if (marker.getAnimation() !== null) {
        marker.setAnimation(null);
    } else {
        marker.setAnimation(google.maps.Animation.BOUNCE);
        setTimeout(function(){ marker.setAnimation(null); }, 3500);
      }
}// END of markerBounce function---------------------------

//---------------------------------------------------------
//View Model
//---------------------------------------------------------
var viewModel = function () {
    var self = this;

    this.query = ko.observable("");
    this.locationsList = ko.observableArray([]);

    for (var i = 0; locations.length > i; i++) {
        self.locationsList.push(new addMarker(locations[i]));
    }

    this.locationList = ko.computed(function() {
        if (self.query().toLowerCase()) {
            return ko.utils.arrayFilter(self.locationsList(), function(location) {
                console.log(location);
                var result = location.name.toLowerCase().includes(self.query().toLowerCase());
                location.visible(result);
                return result;
            });
        }
        self.locationsList().forEach(function(marker) {
        marker.visible(true);
        });
        return self.locationsList(); 
    }, self);
};//END of viewModel-----------------------------------------

//Set the width of the side navigation to 250px and the left margin of the page content to 250px 
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}
// Set the width of the side navigation to 0 and the left margin of the page content to 0 
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
}
// If Google Maps cannot load, display this alert
function mapError() {
    alert("Google Maps has failed to load. Please check your internet connection and try again.");
}

