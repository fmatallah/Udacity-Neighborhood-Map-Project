# neighborhood-map-udacity
Udacity project with knockout JS framework that uses Google Maps API to display the Jeddah City in Saudi Arabia<br/>
The markers display some of the attractions of J-Town <br/>
<br/>

## Setup:
* Clone or [download](ADD MY GITHUB LINK HERE) the repository 
  * Extract files.
  * Open index.html

## Expected Functionality:
* Google map loaded from Maps API.
* Map markers drop at 5 different locations
* Clicking on the marker displays data loaded via Foursquare API in an info. window
* API errors are handled with warning message at top of page
* Locations markers all present upon page load
* Locations markers & list can be filtered by the search bar 
* Page is responsive
* Page is built using Knockout JS

## Attributions:
* [Google Maps API](https://developers.google.com/maps/)
* [Foursquare API](https://developer.foursquare.com/)
* [w3schools](https://www.w3schools.com/howto/howto_js_sidenav.asp) for responsive side nav menu
